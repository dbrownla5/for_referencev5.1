// Email module. Uses Resend if RESEND_API_KEY is set; otherwise logs and no-ops
// so the app runs end-to-end before the key is wired in at deploy.

import { Resend } from 'resend';

const KEY = process.env.RESEND_API_KEY || '';
const FROM = process.env.FROM_EMAIL || 'Dayna at The Well Lived Citizen <dayna@thewelllivedcitizen.com>';
const APP_URL = process.env.APP_URL || 'http://localhost:3000';

const resend = KEY ? new Resend(KEY) : null;

export interface SendResult { ok: boolean; skipped?: boolean; error?: string; }

export async function sendEmail(to: string, subject: string, html: string): Promise<SendResult> {
  if (!resend) {
    console.log(`[email skipped — no RESEND_API_KEY] to=${to} subject="${subject}"`);
    return { ok: true, skipped: true };
  }
  try {
    await resend.emails.send({ from: FROM, to, subject, html });
    return { ok: true };
  } catch (e: any) {
    console.error('Resend error:', e?.message);
    return { ok: false, error: e?.message };
  }
}

const shell = (body: string) => `
  <div style="font-family:Georgia,serif;color:#2b2b28;max-width:560px;margin:0 auto;line-height:1.6">
    ${body}
    <hr style="border:none;border-top:1px solid #e4e0d8;margin:28px 0"/>
    <p style="font-size:12px;color:#8a857a">The Well Lived Citizen · Los Angeles, CA · thewelllivedcitizen.com</p>
  </div>`;

// ---- Templates, one per workflow trigger ----

export const T = {
  intakeConfirm: (h: { name: string; summary: string; bagsCount: string }) => ({
    subject: 'Your bag request — received, agreement on file',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Got your request: <strong>${h.summary || 'bag pickup'}</strong>. Your signed Resale Agreement is on file — thank you.</p>
      <p>Quick confirm: <strong>how many bags — 1 or 2?</strong> (Two max per pickup unless we've set up a session.)</p>
      <p>I'll confirm your pickup window shortly.</p>
      <p>— Dayna</p>`),
  }),

  dayBefore: (h: { name: string; scheduledPickupAt: string }) => ({
    subject: 'Pickup tomorrow — quick item count',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Confirming your pickup for <strong>${h.scheduledPickupAt}</strong>.</p>
      <p>Before then: roughly <strong>how many items</strong> are in the bag(s)? A ballpark is fine — it just helps me verify everything arrives.</p>
      <p>— Dayna</p>`),
  }),

  inventoryConfirm: (h: { name: string; verifiedItemCount: string; summary: string }) => ({
    subject: 'Your items arrived — inventory confirmed',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Everything's here and logged. I counted <strong>${h.verifiedItemCount} items</strong>.</p>
      <p>If that doesn't match what you expected, tell me within 48 hours. Otherwise I'll start the evaluation — I'll go through every piece and send you a full list of what I'm listing, where, and at what price before anything goes live.</p>
      <p>— Dayna</p>`),
  }),

  intakeReport: (h: { name: string; consentToken: string }, itemsHtml: string) => ({
    subject: 'Your resale list — review and approve',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Here's everything from your bag(s) and what I recommend for each piece — platform, starting price, and an estimate of what it should sell for and how fast.</p>
      ${itemsHtml}
      <p style="margin-top:20px"><a href="${APP_URL}/consent/${h.consentToken}" style="background:#6b7257;color:#fff;padding:12px 20px;text-decoration:none;border-radius:4px;display:inline-block">Review &amp; approve your list</a></p>
      <p style="font-size:13px;color:#8a857a">You have 24 hours to approve or pull any items. No response means the list goes live as shown. Your 30-day payout clock starts when you approve.</p>
      <p>— Dayna</p>`),
  }),

  consentReceived: (h: { name: string }) => ({
    subject: 'Approved — your items are going live',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Got your approval. Listings go live now, and your 30-day cycle has started.</p>
      <p>Over the next 4 days you can send me anything that helps a piece sell — provenance, sizing notes, history. After that they run as listed.</p>
      <p>You'll get a sales summary and a payout every 30 days.</p>
      <p>— Dayna</p>`),
  }),

  payout: (h: { name: string }, summaryHtml: string, total: number) => ({
    subject: 'Your 30-day sales summary & payout',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>Here's your 30-day summary. Your payout this cycle: <strong>$${total.toFixed(2)}</strong>, sent via your preferred method.</p>
      ${summaryHtml}
      <p>— Dayna</p>`),
  }),

  noSale: (h: { name: string }) => ({
    subject: 'Your 30-day update',
    html: shell(`
      <p>Hi ${h.name},</p>
      <p>No sales closed this cycle, so there's no payout this month — but your items are live and working. I'll keep you posted.</p>
      <p>— Dayna</p>`),
  }),
};
