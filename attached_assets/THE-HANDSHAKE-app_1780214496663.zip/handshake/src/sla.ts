// SLA + timer helpers. Drives the green/amber/red urgency on every record.

export function businessDaysFromNow(start: Date, days: number): Date {
  const d = new Date(start);
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    const day = d.getDay();
    if (day !== 0 && day !== 6) added++;
  }
  return d;
}

export function hoursFromNow(start: Date, hours: number): Date {
  return new Date(start.getTime() + hours * 3600 * 1000);
}

export function daysFromNow(start: Date, days: number): Date {
  return new Date(start.getTime() + days * 24 * 3600 * 1000);
}

// First Monday strictly after a given date (used for payout date).
export function firstMondayAfter(date: Date): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + 1);
  while (d.getDay() !== 1) d.setDate(d.getDate() + 1);
  return d;
}

export type Urgency = "ok" | "soon" | "overdue" | "none";

export function urgencyFor(due: Date | null): Urgency {
  if (!due) return "none";
  const now = Date.now();
  const ms = due.getTime() - now;
  if (ms < 0) return "overdue";
  if (ms < 12 * 3600 * 1000) return "soon";
  return "ok";
}

// Given a handshake, what's the deadline for its current step?
export function dueForStep(h: {
  step: number;
  createdAt: string;
  scheduledPickupAt: string;
  custodyAt: string;
  inventoryConfirmedAt: string;
  evaluationStartedAt: string;
  reportSentAt: string;
  consentAt: string;
  reviewClosedAt: string;
}, cfg: { INVENTORY_CONFIRM_HOURS: number; EVALUATION_BUSINESS_DAYS_MAX: number; CONSENT_WINDOW_HOURS: number; REVIEW_PERIOD_DAYS: number; PAYOUT_CYCLE_DAYS: number }): Date | null {
  const p = (s: string) => (s ? new Date(s) : null);
  switch (h.step) {
    case 1: return null; // waiting on Dayna to confirm window — no clock
    case 2: return p(h.scheduledPickupAt); // confirm by pickup day
    case 3: return p(h.scheduledPickupAt);
    case 4: { const s = p(h.custodyAt); return s ? hoursFromNow(s, cfg.INVENTORY_CONFIRM_HOURS) : null; }
    case 5: { const s = p(h.evaluationStartedAt); return s ? businessDaysFromNow(s, cfg.EVALUATION_BUSINESS_DAYS_MAX) : null; }
    case 6: return null; // ready to send report — action, not a clock
    case 7: { const s = p(h.reportSentAt); return s ? hoursFromNow(s, cfg.CONSENT_WINDOW_HOURS) : null; }
    case 8: { const s = p(h.consentAt); return s ? daysFromNow(s, cfg.REVIEW_PERIOD_DAYS) : null; }
    case 9: { const s = p(h.consentAt); return s ? daysFromNow(s, cfg.PAYOUT_CYCLE_DAYS) : null; }
    default: return null;
  }
}
