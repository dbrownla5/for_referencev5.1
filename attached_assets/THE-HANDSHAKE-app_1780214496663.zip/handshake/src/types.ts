// THE WELL LIVED CITIZEN — HANDSHAKE
// Shared types for the operational dashboard.

export interface Handshake {
  id: number;
  // --- intake fields (sent by the website webhook) ---
  name: string;
  email: string;
  phone: string;
  neighborhood: string;
  clientType: string;          // "new" | "returning"
  summary: string;
  situation: string;
  returningService: string;
  bagsCount: string;
  urgency: string;
  pickupMethod: string;        // "in-person" | "ups" | "courier"
  pickupTime1: string;
  pickupTime2: string;
  pickupRelease: number;       // 0 | 1
  courierNotes: string;
  estimatedItems: string;
  // --- the legal gate ---
  agreementAccepted: number;   // 0 | 1
  agreementTimestamp: string;  // ISO 8601 — the signature event
  signerName: string;          // typed name = e-signature
  // --- lifecycle ---
  status: string;              // "open" | "blocked-no-agreement" | "closed" | "terminated"
  step: number;                // 1..9
  createdAt: string;

  // --- per-step data captured by Dayna ---
  scheduledPickupAt: string;   // step 1 -> set when she confirms window
  confirmedBagsCount: string;  // step 2 reply
  confirmedItemCount: string;  // step 2 reply (client's stated count)
  custodyMethod: string;       // step 3
  custodyPhoto: string;        // step 3 (filename / data url)
  custodyAt: string;           // step 3 timestamp
  verifiedItemCount: string;   // step 4 (Dayna's verified count)
  inventoryConfirmedAt: string;// step 4 timestamp
  evaluationStartedAt: string; // step 4 -> starts the 7-10 business day clock
  reportSentAt: string;        // step 6 timestamp
  consentToken: string;        // step 6 -> link the client uses to consent
  consentAt: string;           // step 7 timestamp (client signed OR auto by non-response)
  consentMethod: string;       // "signed" | "non-response" | "items-pulled"
  reviewClosedAt: string;      // step 8 timestamp
  payoutClockStartAt: string;  // = consentAt (step 7). The 30-day clock anchor.
  notes: string;               // freeform internal notes
}

export interface LineItem {
  id: number;
  handshakeId: number;
  description: string;
  platform: string;            // Poshmark / eBay / Chairish / local / etc.
  startingPrice: number;
  estSalePrice: number;
  estTurnDays: number;
  tier: string;                // commission tier label
  pathway: string;             // "list" | "donate" | "return" | "biohazard-disposed"
  pulledByClient: number;      // 0 | 1 (client pulled this item during consent)
}

export interface Sale {
  id: number;
  handshakeId: number;
  lineItemId: number;
  soldAt: string;              // ISO
  grossPrice: number;
  platformFees: number;
  shipping: number;
  netPrice: number;            // gross - fees - shipping
  clientShare: number;         // net * client split
  wlcShare: number;
  paidOut: number;             // 0 | 1
  payoutBatch: string;         // which payout cycle it belongs to
}

export interface EventLog {
  id: number;
  handshakeId: number;
  at: string;
  kind: string;                // "email-sent" | "step-advanced" | "custody" | "consent" | "note"
  detail: string;
}

export const WORKFLOW_STEPS: { id: number; label: string; sla: string }[] = [
  { id: 1, label: "Intake & Agreement", sla: "Confirm pickup window" },
  { id: 2, label: "Day-Before Confirmation", sla: "Day before pickup" },
  { id: 3, label: "Custody Transfer", sla: "Pickup day" },
  { id: 4, label: "48-Hour Inventory Confirmation", sla: "48 hours" },
  { id: 5, label: "Evaluation", sla: "7–10 business days" },
  { id: 6, label: "Intake Report", sla: "Send to client" },
  { id: 7, label: "Consent Window", sla: "24 hours" },
  { id: 8, label: "Review Period", sla: "4 days" },
  { id: 9, label: "30-Day Payout Clock", sla: "Every 30 days" },
];

// Locked business constants — change in ONE place if Dayna ever revises.
export const CONFIG = {
  MAX_BAGS_NON_SESSION: 2,
  INVENTORY_CONFIRM_HOURS: 48,
  EVALUATION_BUSINESS_DAYS_MIN: 7,
  EVALUATION_BUSINESS_DAYS_MAX: 10,
  CONSENT_WINDOW_HOURS: 24,
  REVIEW_PERIOD_DAYS: 4,
  PAYOUT_CYCLE_DAYS: 30,
  // Payout clock anchors to CONSENT (step 7), not intake. Locked.
  PAYOUT_CLOCK_ANCHOR: "consent" as "consent" | "intake",
};

// Commission splits (client share) by tier — matches the Resale Agreement.
export const COMMISSION: Record<string, number> = {
  "Clothing & Accessories": 0.45,
  "Designer & Luxury": 0.50,
  "Furniture & Significant Home": 0.50,
  "Full Closet Liquidation": 0.45,
  "Low-Value Volume ($5–$10)": 0.35,
};
