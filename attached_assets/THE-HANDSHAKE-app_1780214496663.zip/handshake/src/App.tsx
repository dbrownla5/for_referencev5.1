import { useState, useEffect, useCallback } from 'react';
import { WORKFLOW_STEPS, COMMISSION } from './types';

const PATHWAYS = ['list', 'donate', 'return', 'biohazard-disposed'];
const TIERS = Object.keys(COMMISSION);

// ───────── auth-aware fetch ─────────
function useApi() {
  const [pass, setPass] = useState<string>(() => sessionStorage.getItem('wlc_pass') || '');
  const call = useCallback(async (url: string, opts: any = {}) => {
    const res = await fetch(url, { ...opts, headers: { 'Content-Type': 'application/json', 'x-passcode': pass, ...(opts.headers || {}) } });
    if (res.status === 401) { sessionStorage.removeItem('wlc_pass'); setPass(''); throw new Error('unauthorized'); }
    return res.json();
  }, [pass]);
  return { pass, setPass: (p: string) => { sessionStorage.setItem('wlc_pass', p); setPass(p); }, call };
}

const money = (n: number) => `$${(n || 0).toFixed(2)}`;
const fmt = (s: string) => s ? new Date(s).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '—';

function dueFor(h: any): Date | null {
  const p = (s: string) => s ? new Date(s) : null;
  const hrs = (s: string, n: number) => p(s) ? new Date(new Date(s).getTime() + n * 3600e3) : null;
  const days = (s: string, n: number) => p(s) ? new Date(new Date(s).getTime() + n * 864e5) : null;
  function bizDays(s: string, n: number) { const d = p(s); if (!d) return null; let a = 0; const x = new Date(d); while (a < n) { x.setDate(x.getDate() + 1); if (x.getDay() !== 0 && x.getDay() !== 6) a++; } return x; }
  switch (h.step) {
    case 2: case 3: return p(h.scheduledPickupAt);
    case 4: return hrs(h.custodyAt, 48);
    case 5: return bizDays(h.evaluationStartedAt, 10);
    case 7: return hrs(h.reportSentAt, 24);
    case 8: return days(h.consentAt, 4);
    case 9: return days(h.consentAt, 30);
    default: return null;
  }
}
function urgency(due: Date | null): string {
  if (!due) return 'none';
  const ms = due.getTime() - Date.now();
  if (ms < 0) return 'overdue';
  if (ms < 12 * 3600e3) return 'soon';
  return 'ok';
}
const URG_COLOR: Record<string, string> = { overdue: '#c0392b', soon: '#d68910', ok: '#6b7257', none: '#b8b3a8' };

// ════════════════════════ CLIENT CONSENT PAGE (public) ════════════════════════
function ClientConsent({ token }: { token: string }) {
  const [data, setData] = useState<any>(null);
  const [items, setItems] = useState<any[]>([]);
  const [pulled, setPulled] = useState<number[]>([]);
  const [done, setDone] = useState(false);
  useEffect(() => { fetch(`/api/consent/${token}`).then(r => r.json()).then(d => { if (d.success) { setData(d.data); setItems(d.items.filter((i: any) => i.pathway === 'list')); } }); }, [token]);
  if (!data) return <div style={{ padding: 40, fontFamily: 'Georgia, serif' }}>Loading…</div>;
  if (done || data.consentAt) return <div style={{ maxWidth: 560, margin: '60px auto', fontFamily: 'Georgia, serif', color: '#2b2b28' }}><h2>Thank you, {data.name}.</h2><p>Your list is approved and your items go live now. Your 30-day cycle has started. You'll get a sales summary and payout every 30 days.</p></div>;
  return (
    <div style={{ maxWidth: 640, margin: '40px auto', fontFamily: 'Georgia, serif', color: '#2b2b28', padding: 16 }}>
      <h2>Your resale list</h2>
      <p>Here's what I recommend listing. Approve it all, or uncheck anything you'd rather have back. You have 24 hours — after that it goes live as shown.</p>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 15, margin: '20px 0' }}>
        <thead><tr><th></th><th style={{ textAlign: 'left', padding: 8 }}>Item</th><th style={{ textAlign: 'left', padding: 8 }}>Platform</th><th style={{ textAlign: 'left', padding: 8 }}>Start</th><th style={{ textAlign: 'left', padding: 8 }}>Est.</th></tr></thead>
        <tbody>{items.map(i => (
          <tr key={i.id} style={{ borderBottom: '1px solid #eee' }}>
            <td style={{ padding: 8 }}><input type="checkbox" checked={!pulled.includes(i.id)} onChange={e => setPulled(p => e.target.checked ? p.filter(x => x !== i.id) : [...p, i.id])} /></td>
            <td style={{ padding: 8 }}>{i.description}</td><td style={{ padding: 8 }}>{i.platform}</td><td style={{ padding: 8 }}>${i.startingPrice}</td><td style={{ padding: 8 }}>~${i.estSalePrice}</td>
          </tr>))}</tbody>
      </table>
      <button onClick={async () => { await fetch(`/api/consent/${token}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pulledItemIds: pulled }) }); setDone(true); }}
        style={{ background: '#6b7257', color: '#fff', border: 'none', padding: '12px 24px', borderRadius: 4, fontSize: 15, cursor: 'pointer' }}>
        Approve {pulled.length ? `(${items.length - pulled.length} items, ${pulled.length} returned)` : 'all items'}
      </button>
    </div>
  );
}

// ════════════════════════ DASHBOARD ════════════════════════
export default function App() {
  const path = window.location.pathname;
  if (path.startsWith('/consent/')) return <ClientConsent token={path.split('/consent/')[1]} />;

  const { pass, setPass, call } = useApi();
  const [list, setList] = useState<any[]>([]);
  const [sel, setSel] = useState<any>(null);
  const [view, setView] = useState<'board' | 'queue'>('queue');
  const [loading, setLoading] = useState(false);
  const [passInput, setPassInput] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { const d = await call('/api/handshakes'); if (d.success) setList(d.data); await call('/api/sweep/consent-timeouts', { method: 'POST' }); } catch {} finally { setLoading(false); }
  }, [call]);
  useEffect(() => { if (pass) load(); }, [pass, load]);

  const openDetail = async (id: number) => { const d = await call(`/api/handshakes/${id}`); if (d.success) setSel(d); };
  const refresh = async () => { await load(); if (sel) openDetail(sel.data.id); };

  if (!pass) return (
    <div style={{ display: 'flex', height: '100vh', alignItems: 'center', justifyContent: 'center', fontFamily: 'system-ui' }}>
      <div style={{ textAlign: 'center' }}>
        <h2 style={{ fontFamily: 'Georgia, serif' }}>The Handshake</h2>
        <input type="password" placeholder="passcode" value={passInput} onChange={e => setPassInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && setPass(passInput)} style={{ padding: 10, fontSize: 16, border: '1px solid #ccc', borderRadius: 4 }} />
        <div><button onClick={() => setPass(passInput)} style={{ marginTop: 12, padding: '10px 20px', background: '#6b7257', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>Enter</button></div>
      </div>
    </div>
  );

  const active = list.filter(h => h.status === 'open');
  const blocked = list.filter(h => h.status === 'blocked-no-agreement');
  const queue = active.map(h => ({ h, due: dueFor(h), u: urgency(dueFor(h)) }))
    .sort((a, b) => (a.due?.getTime() || 9e15) - (b.due?.getTime() || 9e15));

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', color: '#2b2b28', minHeight: '100vh', background: '#faf8f4' }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 24px', borderBottom: '1px solid #e4e0d8', background: '#fff' }}>
        <strong style={{ fontFamily: 'Georgia, serif', fontSize: 18 }}>The Handshake</strong>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => setView('queue')} style={tab(view === 'queue')}>Action Queue</button>
          <button onClick={() => setView('board')} style={tab(view === 'board')}>Board</button>
          <button onClick={refresh} style={{ ...tab(false), color: '#6b7257' }}>{loading ? '…' : '↻'}</button>
        </div>
      </header>

      {blocked.length > 0 && (
        <div style={{ background: '#fbeaea', borderBottom: '1px solid #e8c4c4', padding: '8px 24px', fontSize: 13, color: '#c0392b' }}>
          ⚠ {blocked.length} submission(s) with no signed agreement — not picked up. {blocked.map(b => b.name).join(', ')}
        </div>
      )}

      <div style={{ display: 'flex' }}>
        <main style={{ flex: 1, padding: 24 }}>
          {view === 'queue' ? (
            <div>
              <h3 style={{ marginTop: 0 }}>What needs you now</h3>
              {queue.length === 0 && <p style={{ color: '#8a857a' }}>Nothing waiting. Clean board.</p>}
              {queue.map(({ h, due, u }) => (
                <div key={h.id} onClick={() => openDetail(h.id)} style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '12px 14px', background: '#fff', border: '1px solid #e4e0d8', borderLeft: `4px solid ${URG_COLOR[u]}`, borderRadius: 4, marginBottom: 8, cursor: 'pointer' }}>
                  <div style={{ width: 8, height: 8, borderRadius: 8, background: URG_COLOR[u] }} />
                  <div style={{ flex: 1 }}><strong>{h.name}</strong> <span style={{ color: '#8a857a', fontSize: 13 }}>· {h.bagsCount || '?'} bag(s) · {h.pickupMethod || '—'}</span></div>
                  <div style={{ fontSize: 13, color: '#6b7257' }}>{stepLabel(h.step)}</div>
                  <div style={{ fontSize: 12, color: URG_COLOR[u], width: 120, textAlign: 'right' }}>{u === 'overdue' ? 'OVERDUE' : due ? `due ${fmt(due.toISOString())}` : 'action ready'}</div>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ display: 'flex', gap: 12, overflowX: 'auto' }}>
              {WORKFLOW_STEPS.map(s => (
                <div key={s.id} style={{ minWidth: 200, background: '#f1eee7', borderRadius: 6, padding: 10 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: '#6b7257', marginBottom: 8 }}>{s.id}. {s.label}</div>
                  {active.filter(h => h.step === s.id).map(h => (
                    <div key={h.id} onClick={() => openDetail(h.id)} style={{ background: '#fff', border: '1px solid #e4e0d8', borderRadius: 4, padding: 8, marginBottom: 6, cursor: 'pointer', fontSize: 13 }}>
                      <strong>{h.name}</strong><div style={{ color: '#8a857a', fontSize: 11 }}>{h.bagsCount || '?'} bag(s)</div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </main>

        {sel && <Detail sel={sel} call={call} onClose={() => setSel(null)} onChange={refresh} />}
      </div>
    </div>
  );
}

function tab(active: boolean): any { return { padding: '6px 14px', border: '1px solid #e4e0d8', background: active ? '#6b7257' : '#fff', color: active ? '#fff' : '#2b2b28', borderRadius: 4, cursor: 'pointer', fontSize: 13 }; }
const stepLabel = (n: number) => WORKFLOW_STEPS.find(s => s.id === n)?.label || `Step ${n}`;
const btn: any = { padding: '8px 16px', background: '#6b7257', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontSize: 13 };
const inp: any = { padding: 6, border: '1px solid #ccc', borderRadius: 3, fontSize: 13, width: '100%', boxSizing: 'border-box' };

// ───────── detail / action panel ─────────
function Detail({ sel, call, onClose, onChange }: any) {
  const h = sel.data; const items = sel.items || []; const sales = sel.sales || [];
  const [draft, setDraft] = useState<any>({});
  const set = (k: string, v: any) => setDraft((d: any) => ({ ...d, [k]: v }));
  const act = async (url: string, body: any = {}) => { await call(url, { method: 'POST', body: JSON.stringify(body) }); setDraft({}); onChange(); };

  return (
    <aside style={{ width: 420, borderLeft: '1px solid #e4e0d8', background: '#fff', padding: 20, height: 'calc(100vh - 53px)', overflowY: 'auto', position: 'sticky', top: 53 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}><h3 style={{ margin: 0 }}>{h.name}</h3><button onClick={onClose} style={{ border: 'none', background: 'none', fontSize: 20, cursor: 'pointer' }}>×</button></div>
      <div style={{ fontSize: 13, color: '#8a857a', marginBottom: 4 }}>{h.email} · {h.phone}</div>

      {h.agreementAccepted ? (
        <div style={{ fontSize: 12, color: '#6b7257', background: '#eef1e8', padding: '6px 10px', borderRadius: 4, margin: '8px 0' }}>✓ Agreement signed by {h.signerName || h.name} · {fmt(h.agreementTimestamp)}</div>
      ) : (
        <div style={{ fontSize: 12, color: '#c0392b', background: '#fbeaea', padding: '6px 10px', borderRadius: 4, margin: '8px 0' }}>⚠ NO AGREEMENT — do not pick up</div>
      )}

      <div style={{ fontSize: 13, margin: '8px 0', padding: '8px 10px', background: '#f7f5f0', borderRadius: 4 }}>
        <strong>Step {h.step}: {stepLabel(h.step)}</strong><br />
        {h.summary} · {h.bagsCount || '?'} bag(s) · est {h.estimatedItems || '?'} items · {h.pickupMethod} · {h.urgency}
        {h.situation && <div style={{ marginTop: 4, color: '#8a857a' }}>{h.situation}</div>}
      </div>

      {/* STEP ACTIONS */}
      {h.step === 1 && <Action label="Confirm pickup window">
        <input style={inp} placeholder="e.g. Tue May 6, 2–4pm" onChange={e => set('scheduledPickupAt', e.target.value)} />
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/confirm-window`, { scheduledPickupAt: draft.scheduledPickupAt })}>Set window → Step 2</button>
      </Action>}

      {h.step === 2 && <Action label="Day-before confirmation">
        <input style={inp} placeholder="client's stated item count" onChange={e => set('confirmedItemCount', e.target.value)} />
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/day-before`, { confirmedItemCount: draft.confirmedItemCount })}>Send confirmation email</button>
        <button style={{ ...btn, background: '#444' }} onClick={() => act(`/api/handshakes/${h.id}/custody`, {})}>Skip to custody →</button>
      </Action>}

      {h.step === 3 && <Action label="Log custody transfer">
        <select style={inp} onChange={e => set('custodyMethod', e.target.value)}><option value="">method…</option><option>in-person</option><option>ups</option><option>courier</option></select>
        <input style={inp} placeholder="photo url / note (required)" onChange={e => set('custodyPhoto', e.target.value)} />
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/custody`, draft)}>Log custody → Step 4</button>
      </Action>}

      {h.step === 4 && <Action label="48-hour inventory confirmation">
        <input style={inp} placeholder="your verified item count" onChange={e => set('verifiedItemCount', e.target.value)} />
        <div style={{ fontSize: 12, color: '#8a857a' }}>Client said: {h.confirmedItemCount || h.estimatedItems || '?'}</div>
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/inventory-confirm`, { verifiedItemCount: draft.verifiedItemCount })}>Confirm & email client → Step 5</button>
      </Action>}

      {h.step === 5 && <ReportBuilder h={h} items={items} call={call} onChange={onChange} />}

      {h.step === 6 && <Action label="Send intake report">
        <div style={{ fontSize: 12, color: '#8a857a' }}>{items.filter((i: any) => i.pathway === 'list').length} items to list. Sends the client their list + 24h consent link.</div>
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/send-report`, {})}>Send report → Step 7</button>
      </Action>}

      {h.step === 7 && <Action label="Consent window (24h)">
        <div style={{ fontSize: 13 }}>Report sent {fmt(h.reportSentAt)}. Waiting on client.</div>
        <div style={{ fontSize: 12, color: '#8a857a' }}>Auto-advances after 24h if no response. Consent link: <code>/consent/{h.consentToken}</code></div>
      </Action>}

      {h.step === 8 && <Action label="Review period (4 days)">
        <div style={{ fontSize: 13 }}>Approved {fmt(h.consentAt)} ({h.consentMethod}). Listings live. Payout clock running.</div>
        <button style={btn} onClick={() => act(`/api/handshakes/${h.id}/close-review`, {})}>Close review → Step 9</button>
      </Action>}

      {h.step === 9 && <PayoutPanel h={h} items={items} sales={sales} call={call} onChange={onChange} />}

      {/* timeline */}
      <details style={{ marginTop: 16 }}>
        <summary style={{ cursor: 'pointer', fontSize: 13, color: '#6b7257' }}>History ({(sel.events || []).length})</summary>
        {(sel.events || []).map((e: any) => <div key={e.id} style={{ fontSize: 12, color: '#8a857a', padding: '2px 0' }}>{fmt(e.at)} — {e.detail}</div>)}
      </details>
    </aside>
  );
}

function Action({ label, children }: any) {
  return <div style={{ border: '1px solid #d8e0cc', background: '#f6f8f1', borderRadius: 6, padding: 12, margin: '12px 0', display: 'flex', flexDirection: 'column', gap: 8 }}>
    <strong style={{ fontSize: 13 }}>{label}</strong>{children}
  </div>;
}

function ReportBuilder({ h, items, call, onChange }: any) {
  const [d, setD] = useState<any>({ pathway: 'list', tier: TIERS[0] });
  const set = (k: string, v: any) => setD((p: any) => ({ ...p, [k]: v }));
  const add = async () => { await call(`/api/handshakes/${h.id}/items`, { method: 'POST', body: JSON.stringify(d) }); setD({ pathway: 'list', tier: TIERS[0] }); onChange(); };
  const del = async (id: number) => { await call(`/api/handshakes/${h.id}/items/${id}`, { method: 'DELETE' }); onChange(); };
  return (
    <Action label="Evaluation — build the resale list">
      {items.map((i: any) => (
        <div key={i.id} style={{ fontSize: 12, display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid #e4e0d8', padding: '3px 0' }}>
          <span>{i.pathway === 'list' ? `${i.description} · ${i.platform} · $${i.startingPrice}→~$${i.estSalePrice}` : `${i.description} · ${i.pathway}`}</span>
          <span onClick={() => del(i.id)} style={{ cursor: 'pointer', color: '#c0392b' }}>×</span>
        </div>
      ))}
      <input style={inp} placeholder="item description" value={d.description || ''} onChange={e => set('description', e.target.value)} />
      <select style={inp} value={d.pathway} onChange={e => set('pathway', e.target.value)}>{PATHWAYS.map(p => <option key={p}>{p}</option>)}</select>
      {d.pathway === 'list' && <>
        <input style={inp} placeholder="platform (Poshmark/eBay/Chairish…)" value={d.platform || ''} onChange={e => set('platform', e.target.value)} />
        <div style={{ display: 'flex', gap: 4 }}>
          <input style={inp} placeholder="start $" onChange={e => set('startingPrice', e.target.value)} />
          <input style={inp} placeholder="est sale $" onChange={e => set('estSalePrice', e.target.value)} />
          <input style={inp} placeholder="turn (days)" onChange={e => set('estTurnDays', e.target.value)} />
        </div>
        <select style={inp} value={d.tier} onChange={e => set('tier', e.target.value)}>{TIERS.map(t => <option key={t}>{t}</option>)}</select>
      </>}
      <button style={{ ...btn, background: '#444' }} onClick={add}>+ Add item</button>
      <button style={btn} onClick={async () => { await call(`/api/handshakes/${h.id}/advance-to-report`, { method: 'POST', body: JSON.stringify({}) }).catch(() => {}); onChange(); }}>Done evaluating → ready to send</button>
    </Action>
  );
}

function PayoutPanel({ h, items, sales, call, onChange }: any) {
  const [d, setD] = useState<any>({});
  const set = (k: string, v: any) => setD((p: any) => ({ ...p, [k]: v }));
  const listed = items.filter((i: any) => i.pathway === 'list' && !i.pulledByClient);
  const recordSale = async () => { await call(`/api/handshakes/${h.id}/sales`, { method: 'POST', body: JSON.stringify(d) }); setD({}); onChange(); };
  const runPayout = async () => { const r = await call(`/api/handshakes/${h.id}/payout`, { method: 'POST', body: JSON.stringify({}) }); alert(`Payout: $${r.total.toFixed(2)}. Next payout date: ${r.nextPayout}`); onChange(); };
  const unpaid = sales.filter((s: any) => !s.paidOut).reduce((a: number, s: any) => a + s.clientShare, 0);
  return (
    <Action label="Listings live — record sales & pay out">
      <div style={{ fontSize: 12, color: '#8a857a' }}>Clock started {fmt(h.payoutClockStartAt)}. {listed.length} items live.</div>
      <select style={inp} value={d.lineItemId || ''} onChange={e => { const it = listed.find((x: any) => x.id === +e.target.value); set('lineItemId', e.target.value); set('tier', it?.tier); }}>
        <option value="">item sold…</option>{listed.map((i: any) => <option key={i.id} value={i.id}>{i.description}</option>)}
      </select>
      <div style={{ display: 'flex', gap: 4 }}>
        <input style={inp} placeholder="gross $" onChange={e => set('grossPrice', e.target.value)} />
        <input style={inp} placeholder="fees $" onChange={e => set('platformFees', e.target.value)} />
        <input style={inp} placeholder="ship $" onChange={e => set('shipping', e.target.value)} />
      </div>
      <button style={{ ...btn, background: '#444' }} onClick={recordSale}>+ Record sale</button>
      {sales.map((s: any) => <div key={s.id} style={{ fontSize: 12, color: s.paidOut ? '#8a857a' : '#2b2b28' }}>{fmt(s.soldAt)} · gross {money(s.grossPrice)} · client {money(s.clientShare)} {s.paidOut ? '· paid' : ''}</div>)}
      <div style={{ fontSize: 13, fontWeight: 700 }}>Owed this cycle: {money(unpaid)}</div>
      <button style={btn} onClick={runPayout}>Run payout & email summary</button>
    </Action>
  );
}
