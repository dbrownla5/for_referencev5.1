# The Handshake — operational dashboard for The Well Lived Citizen

Runs the full Fast Bag Fill / resale lifecycle: one record per client, opened at
intake by a signed agreement, carried through to payout.

## What's in here (all working, tested end-to-end)
- **Agreement gate** — a submission with no `agreementAccepted` + `agreementTimestamp`
  is stored as `blocked-no-agreement` and never enters the board. No signature, no pickup.
- **9-step engine** — each step has a real action that records data, stamps a timestamp,
  fires the client email, and advances. Intake → day-before → custody → 48h inventory →
  7–10 business-day evaluation → intake report → 24h consent → 4-day review → 30-day payout.
- **Inventory / intake-report builder** — add each item (platform, start price, est. sale,
  est. turn, tier, pathway: list/donate/return/biohazard-disposed), then send the client
  their list with one click.
- **Client consent page** (`/consent/:token`) — client approves the list or pulls items.
  No response in 24h auto-advances. Consent stamps the payout clock.
- **Payout tracking** — record sales, splits computed off the tier (matches the agreement),
  run a payout that emails the summary and dates the next one to the first Monday after.
- **Action queue** (what needs you now, by deadline) + **board** (by step) + **no-agreement list**.

## Run it
1. `npm install`
2. Copy `.env.example` to `.env`, set `DASHBOARD_PASSCODE`. (Email is optional — without
   `RESEND_API_KEY` it runs fine and logs emails instead of sending.)
3. Dev: `npm run dev` → http://localhost:3000
4. Production: `npm run build` then `npm start`

## Wire the website to it (the only integration)
The live site already collects the intake fields. Two changes there:
1. Add the **AgreementGate** component (in the `website-agreement-gate/` folder of this
   delivery) to the bag/resale path of `Contact.tsx`. It produces `agreementAccepted`,
   `agreementTimestamp`, and `signerName`. Block submit until it has fired.
2. On submit, POST the full form (including those three fields) to this app's
   `POST /api/webhook`. That's it — nothing else changes on the website.

## Email
Set `RESEND_API_KEY` (and a verified `FROM_EMAIL` domain). Reuse the same Resend account
the website contact form already uses. Templates live in `src/email.ts` — edit the wording
there; the flow doesn't change.

## Notes
- SQLite file `handshakes.db` persists data. On an ephemeral host, mount a volume for it
  or swap the three `db.prepare` table definitions to your managed datastore — field names
  stay identical.
- Locked business constants (windows, max bags, payout anchor) are in `src/types.ts` → `CONFIG`.
  Change them in that one place if ever revised.
