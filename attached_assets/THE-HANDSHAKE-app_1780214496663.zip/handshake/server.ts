import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';
import { createServer as createViteServer } from 'vite';
import { randomBytes } from 'crypto';
import { CONFIG, COMMISSION } from './src/types.js';
import { firstMondayAfter } from './src/sla.js';
import { sendEmail, T } from './src/email.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database(path.join(__dirname, 'handshakes.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS handshakes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT, email TEXT, phone TEXT, neighborhood TEXT, clientType TEXT,
    summary TEXT, situation TEXT, returningService TEXT,
    bagsCount TEXT, urgency TEXT, pickupMethod TEXT, pickupTime1 TEXT, pickupTime2 TEXT,
    pickupRelease INTEGER, courierNotes TEXT, estimatedItems TEXT,
    agreementAccepted INTEGER, agreementTimestamp TEXT, signerName TEXT,
    status TEXT DEFAULT 'open', step INTEGER DEFAULT 1, createdAt TEXT DEFAULT CURRENT_TIMESTAMP,
    scheduledPickupAt TEXT DEFAULT '', confirmedBagsCount TEXT DEFAULT '', confirmedItemCount TEXT DEFAULT '',
    custodyMethod TEXT DEFAULT '', custodyPhoto TEXT DEFAULT '', custodyAt TEXT DEFAULT '',
    verifiedItemCount TEXT DEFAULT '', inventoryConfirmedAt TEXT DEFAULT '', evaluationStartedAt TEXT DEFAULT '',
    reportSentAt TEXT DEFAULT '', consentToken TEXT DEFAULT '', consentAt TEXT DEFAULT '',
    consentMethod TEXT DEFAULT '', reviewClosedAt TEXT DEFAULT '', payoutClockStartAt TEXT DEFAULT '',
    notes TEXT DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS line_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    handshakeId INTEGER, description TEXT, platform TEXT,
    startingPrice REAL DEFAULT 0, estSalePrice REAL DEFAULT 0, estTurnDays INTEGER DEFAULT 0,
    tier TEXT DEFAULT '', pathway TEXT DEFAULT 'list', pulledByClient INTEGER DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    handshakeId INTEGER, lineItemId INTEGER, soldAt TEXT,
    grossPrice REAL, platformFees REAL, shipping REAL, netPrice REAL,
    clientShare REAL, wlcShare REAL, paidOut INTEGER DEFAULT 0, payoutBatch TEXT DEFAULT ''
  );
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    handshakeId INTEGER, at TEXT DEFAULT CURRENT_TIMESTAMP, kind TEXT, detail TEXT
  );
`);

const now = () => new Date().toISOString();
const logEvent = db.prepare(`INSERT INTO events (handshakeId, at, kind, detail) VALUES (?, ?, ?, ?)`);
const log = (id: number, kind: string, detail: string) => logEvent.run(id, now(), kind, detail);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
app.use(cors());
app.use(express.json({ limit: '12mb' })); // headroom for custody photo data-urls

// ───────────────────────── auth (single shared passcode) ─────────────────────────
const PASSCODE = process.env.DASHBOARD_PASSCODE || 'changeme';
function requireAuth(req: any, res: any, next: any) {
  if ((req.headers['x-passcode'] || '') === PASSCODE) return next();
  return res.status(401).json({ success: false, error: 'unauthorized' });
}

// ───────────────────────── webhook from the website ─────────────────────────
const insert = db.prepare(`
  INSERT INTO handshakes (
    name,email,phone,neighborhood,clientType,summary,situation,returningService,
    bagsCount,urgency,pickupMethod,pickupTime1,pickupTime2,pickupRelease,courierNotes,estimatedItems,
    agreementAccepted,agreementTimestamp,signerName,status,step,createdAt
  ) VALUES (
    @name,@email,@phone,@neighborhood,@clientType,@summary,@situation,@returningService,
    @bagsCount,@urgency,@pickupMethod,@pickupTime1,@pickupTime2,@pickupRelease,@courierNotes,@estimatedItems,
    @agreementAccepted,@agreementTimestamp,@signerName,@status,@step,@createdAt
  )`);

app.post('/api/webhook', async (req, res) => {
  try {
    const d = req.body || {};
    const signed = d.agreementAccepted === true && !!d.agreementTimestamp;
    const status = signed ? 'open' : 'blocked-no-agreement';
    const info = insert.run({
      name: d.name || '', email: d.email || '', phone: d.phone || '', neighborhood: d.neighborhood || '',
      clientType: d.clientType || '', summary: d.summary || '', situation: d.situation || '',
      returningService: d.returningService || '', bagsCount: d.bagsCount || '', urgency: d.urgency || '',
      pickupMethod: d.pickupMethod || '', pickupTime1: d.pickupTime1 || '', pickupTime2: d.pickupTime2 || '',
      pickupRelease: d.pickupRelease === true ? 1 : 0, courierNotes: d.courierNotes || '',
      estimatedItems: d.estimatedItems || '',
      agreementAccepted: signed ? 1 : 0, agreementTimestamp: d.agreementTimestamp || '',
      signerName: d.signerName || '', status, step: 1, createdAt: now(),
    });
    const id = Number(info.lastInsertRowid);
    log(id, 'intake', signed ? 'Handshake opened — agreement signed' : 'BLOCKED — no agreement signature');
    // Over-bag flag
    if (Number(d.bagsCount) > CONFIG.MAX_BAGS_NON_SESSION) log(id, 'flag', `bagsCount ${d.bagsCount} exceeds non-session max`);
    if (signed) {
      const t = T.intakeConfirm({ name: d.name, summary: d.summary, bagsCount: d.bagsCount });
      const r = await sendEmail(d.email, t.subject, t.html);
      log(id, 'email-sent', `intake confirm ${r.skipped ? '(skipped: no key)' : ''}`);
    }
    res.status(200).json({ success: true, id, gated: !signed });
  } catch (e: any) {
    console.error('webhook', e); res.status(500).json({ success: false, error: e.message });
  }
});

// ───────────────────────── reads ─────────────────────────
const allHandshakes = db.prepare(`SELECT * FROM handshakes ORDER BY createdAt DESC`);
const oneHandshake = db.prepare(`SELECT * FROM handshakes WHERE id = ?`);
const itemsFor = db.prepare(`SELECT * FROM line_items WHERE handshakeId = ? ORDER BY id`);
const salesFor = db.prepare(`SELECT * FROM sales WHERE handshakeId = ? ORDER BY soldAt DESC`);
const eventsFor = db.prepare(`SELECT * FROM events WHERE handshakeId = ? ORDER BY at DESC`);

app.get('/api/handshakes', requireAuth, (_req, res) => {
  res.json({ success: true, data: allHandshakes.all() });
});
app.get('/api/handshakes/:id', requireAuth, (req, res) => {
  const h = oneHandshake.get(req.params.id);
  if (!h) return res.status(404).json({ success: false });
  res.json({ success: true, data: h, items: itemsFor.all(req.params.id), sales: salesFor.all(req.params.id), events: eventsFor.all(req.params.id) });
});

// generic field setter
const setFields = (id: number, fields: Record<string, any>) => {
  const keys = Object.keys(fields);
  if (!keys.length) return;
  const sql = `UPDATE handshakes SET ${keys.map(k => `${k} = @${k}`).join(', ')} WHERE id = @id`;
  db.prepare(sql).run({ ...fields, id });
};

// ───────────────────────── step actions ─────────────────────────
// STEP 1 -> confirm pickup window -> step 2
app.post('/api/handshakes/:id/confirm-window', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  setFields(id, { scheduledPickupAt: req.body.scheduledPickupAt || '', step: 2 });
  log(id, 'step-advanced', `pickup window set: ${req.body.scheduledPickupAt}`);
  res.json({ success: true });
});

// STEP 2 -> send day-before email (asks item count) ; client count stored when they reply / Dayna enters it
app.post('/api/handshakes/:id/day-before', requireAuth, async (req, res) => {
  const id = Number(req.params.id); const h: any = oneHandshake.get(id);
  setFields(id, { confirmedItemCount: req.body.confirmedItemCount ?? h.confirmedItemCount });
  const t = T.dayBefore(h); const r = await sendEmail(h.email, t.subject, t.html);
  log(id, 'email-sent', `day-before ${r.skipped ? '(skipped)' : ''}`);
  res.json({ success: true });
});

// STEP 3 -> log custody transfer -> step 4 (starts 48h clock)
app.post('/api/handshakes/:id/custody', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  setFields(id, { custodyMethod: req.body.custodyMethod || '', custodyPhoto: req.body.custodyPhoto || '', custodyAt: now(), step: 4 });
  log(id, 'custody', `custody via ${req.body.custodyMethod}`);
  res.json({ success: true });
});

// STEP 4 -> confirm inventory -> step 5 (starts evaluation clock)
app.post('/api/handshakes/:id/inventory-confirm', requireAuth, async (req, res) => {
  const id = Number(req.params.id); const h: any = oneHandshake.get(id);
  setFields(id, { verifiedItemCount: req.body.verifiedItemCount || '', inventoryConfirmedAt: now(), evaluationStartedAt: now(), step: 5 });
  const t = T.inventoryConfirm({ ...h, verifiedItemCount: req.body.verifiedItemCount }); const r = await sendEmail(h.email, t.subject, t.html);
  log(id, 'email-sent', `inventory confirm ${r.skipped ? '(skipped)' : ''}`);
  res.json({ success: true });
});

// STEP 5 — line item builder (the inventory/intake report tool)
const insItem = db.prepare(`INSERT INTO line_items (handshakeId,description,platform,startingPrice,estSalePrice,estTurnDays,tier,pathway) VALUES (?,?,?,?,?,?,?,?)`);
const updItem = db.prepare(`UPDATE line_items SET description=@description,platform=@platform,startingPrice=@startingPrice,estSalePrice=@estSalePrice,estTurnDays=@estTurnDays,tier=@tier,pathway=@pathway WHERE id=@id`);
const delItem = db.prepare(`DELETE FROM line_items WHERE id=? AND handshakeId=?`);

app.post('/api/handshakes/:id/items', requireAuth, (req, res) => {
  const id = Number(req.params.id); const i = req.body;
  const info = insItem.run(id, i.description||'', i.platform||'', +i.startingPrice||0, +i.estSalePrice||0, +i.estTurnDays||0, i.tier||'', i.pathway||'list');
  res.json({ success: true, id: info.lastInsertRowid });
});
app.put('/api/handshakes/:id/items/:itemId', requireAuth, (req, res) => {
  const i = req.body;
  updItem.run({ id: Number(req.params.itemId), description: i.description||'', platform: i.platform||'', startingPrice: +i.startingPrice||0, estSalePrice: +i.estSalePrice||0, estTurnDays: +i.estTurnDays||0, tier: i.tier||'', pathway: i.pathway||'list' });
  res.json({ success: true });
});
app.delete('/api/handshakes/:id/items/:itemId', requireAuth, (req, res) => {
  delItem.run(Number(req.params.itemId), Number(req.params.id)); res.json({ success: true });
});

// STEP 5 -> done evaluating -> step 6 (ready to send report)
app.post('/api/handshakes/:id/advance-to-report', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  setFields(id, { step: 6 });
  log(id, 'step-advanced', 'evaluation complete, report ready to send');
  res.json({ success: true });
});

// STEP 6 -> send intake report -> step 7 (mints consent token, starts 24h clock)
function reportItemsHtml(items: any[]) {
  const listed = items.filter(i => i.pathway === 'list');
  const other = items.filter(i => i.pathway !== 'list');
  const rows = listed.map(i => `<tr><td style="padding:6px 10px;border-bottom:1px solid #eee">${i.description}</td><td style="padding:6px 10px;border-bottom:1px solid #eee">${i.platform}</td><td style="padding:6px 10px;border-bottom:1px solid #eee">$${i.startingPrice}</td><td style="padding:6px 10px;border-bottom:1px solid #eee">~$${i.estSalePrice}</td><td style="padding:6px 10px;border-bottom:1px solid #eee">~${i.estTurnDays}d</td></tr>`).join('');
  const otherHtml = other.length ? `<p style="margin-top:14px;font-size:13px;color:#8a857a">Other pathways: ${other.map(i => `${i.description} (${i.pathway === 'biohazard-disposed' ? 'disposed for safety' : i.pathway})`).join('; ')}.</p>` : '';
  return `<table style="border-collapse:collapse;width:100%;font-size:14px"><thead><tr><th style="text-align:left;padding:6px 10px">Item</th><th style="text-align:left;padding:6px 10px">Platform</th><th style="text-align:left;padding:6px 10px">Start</th><th style="text-align:left;padding:6px 10px">Est. sale</th><th style="text-align:left;padding:6px 10px">Est. turn</th></tr></thead><tbody>${rows}</tbody></table>${otherHtml}`;
}

app.post('/api/handshakes/:id/send-report', requireAuth, async (req, res) => {
  const id = Number(req.params.id); const h: any = oneHandshake.get(id);
  const items = itemsFor.all(id) as any[];
  const token = randomBytes(16).toString('hex');
  setFields(id, { reportSentAt: now(), consentToken: token, step: 7 });
  const t = T.intakeReport({ name: h.name, consentToken: token }, reportItemsHtml(items));
  const r = await sendEmail(h.email, t.subject, t.html);
  log(id, 'email-sent', `intake report ${r.skipped ? '(skipped)' : ''}`);
  res.json({ success: true, consentUrl: `/consent/${token}` });
});

// STEP 7 — client-facing consent (PUBLIC, no auth — reached by emailed token)
const byToken = db.prepare(`SELECT * FROM handshakes WHERE consentToken = ?`);
app.get('/api/consent/:token', (req, res) => {
  const h: any = byToken.get(req.params.token);
  if (!h) return res.status(404).json({ success: false });
  res.json({ success: true, data: { id: h.id, name: h.name, consentAt: h.consentAt }, items: itemsFor.all(h.id) });
});
app.post('/api/consent/:token', async (req, res) => {
  const h: any = byToken.get(req.params.token);
  if (!h) return res.status(404).json({ success: false });
  if (h.consentAt) return res.json({ success: true, already: true });
  const pulled: number[] = Array.isArray(req.body.pulledItemIds) ? req.body.pulledItemIds : [];
  pulled.forEach(iid => db.prepare(`UPDATE line_items SET pulledByClient=1, pathway='return' WHERE id=? AND handshakeId=?`).run(iid, h.id));
  const anchor = now();
  setFields(h.id, { consentAt: anchor, consentMethod: pulled.length ? 'items-pulled' : 'signed', payoutClockStartAt: anchor, step: 8 });
  log(h.id, 'consent', `client approved${pulled.length ? `, pulled ${pulled.length} item(s)` : ''}`);
  const t = T.consentReceived({ name: h.name }); const r = await sendEmail(h.email, t.subject, t.html);
  log(h.id, 'email-sent', `consent received ${r.skipped ? '(skipped)' : ''}`);
  res.json({ success: true });
});

// auto-advance consent on 24h non-response (called by a cron/timer or the dashboard on load)
app.post('/api/sweep/consent-timeouts', requireAuth, (_req, res) => {
  const open = db.prepare(`SELECT * FROM handshakes WHERE step = 7 AND consentAt = '' AND reportSentAt != ''`).all() as any[];
  let advanced = 0;
  for (const h of open) {
    if (Date.now() - new Date(h.reportSentAt).getTime() > CONFIG.CONSENT_WINDOW_HOURS * 3600 * 1000) {
      const anchor = now();
      setFields(h.id, { consentAt: anchor, consentMethod: 'non-response', payoutClockStartAt: anchor, step: 8 });
      log(h.id, 'consent', 'auto-advanced — no response in 24h, listings proceed');
      advanced++;
    }
  }
  res.json({ success: true, advanced });
});

// STEP 8 -> close review -> step 9
app.post('/api/handshakes/:id/close-review', requireAuth, (req, res) => {
  const id = Number(req.params.id);
  setFields(id, { reviewClosedAt: now(), step: 9 });
  log(id, 'step-advanced', 'review period closed, listings run as-is');
  res.json({ success: true });
});

// STEP 9 — record a sale (computes split off the tier)
app.post('/api/handshakes/:id/sales', requireAuth, (req, res) => {
  const id = Number(req.params.id); const s = req.body;
  const net = (+s.grossPrice||0) - (+s.platformFees||0) - (+s.shipping||0);
  const split = COMMISSION[s.tier] ?? 0.45;
  const clientShare = +(net * split).toFixed(2);
  const info = db.prepare(`INSERT INTO sales (handshakeId,lineItemId,soldAt,grossPrice,platformFees,shipping,netPrice,clientShare,wlcShare,paidOut,payoutBatch) VALUES (?,?,?,?,?,?,?,?,?,0,'')`)
    .run(id, +s.lineItemId||0, now(), +s.grossPrice||0, +s.platformFees||0, +s.shipping||0, net, clientShare, +(net-clientShare).toFixed(2));
  log(id, 'sale', `$${s.grossPrice} gross, client gets $${clientShare}`);
  res.json({ success: true, id: info.lastInsertRowid, clientShare });
});

// STEP 9 — run a payout (marks unpaid sales paid, emails summary, sets next payout date)
app.post('/api/handshakes/:id/payout', requireAuth, async (req, res) => {
  const id = Number(req.params.id); const h: any = oneHandshake.get(id);
  const unpaid = db.prepare(`SELECT * FROM sales WHERE handshakeId=? AND paidOut=0`).all(id) as any[];
  const total = unpaid.reduce((s, x) => s + x.clientShare, 0);
  const batch = `payout-${now().slice(0,10)}`;
  unpaid.forEach(x => db.prepare(`UPDATE sales SET paidOut=1, payoutBatch=? WHERE id=?`).run(batch, x.id));
  const nextPayout = firstMondayAfter(new Date()).toISOString().slice(0,10);
  if (total > 0) {
    const summary = `<table style="border-collapse:collapse;width:100%;font-size:14px">${unpaid.map(x=>`<tr><td style="padding:4px 8px">Sold $${x.grossPrice}</td><td style="padding:4px 8px">Your share $${x.clientShare}</td></tr>`).join('')}</table>`;
    const t = T.payout({ name: h.name }, summary, total); const r = await sendEmail(h.email, t.subject, t.html);
    log(id, 'payout', `$${total.toFixed(2)} (${unpaid.length} sales) ${r.skipped?'(email skipped)':''}`);
  } else {
    const t = T.noSale({ name: h.name }); await sendEmail(h.email, t.subject, t.html);
    log(id, 'payout', 'no sales this cycle — status update sent');
  }
  res.json({ success: true, total, nextPayout });
});

// notes + manual status
app.post('/api/handshakes/:id/note', requireAuth, (req, res) => {
  const id = Number(req.params.id); setFields(id, { notes: req.body.notes || '' }); log(id, 'note', 'note updated'); res.json({ success: true });
});
app.post('/api/handshakes/:id/status', requireAuth, (req, res) => {
  const id = Number(req.params.id); setFields(id, { status: req.body.status || 'open' }); log(id, 'status', req.body.status); res.json({ success: true });
});

// ───────────────────────── serve frontend ─────────────────────────
async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: 'spa' });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }
  app.listen(PORT, '0.0.0.0', () => console.log(`Handshake server on ${PORT}`));
}
start();
