export interface Handshake {
  id: number;
  name: string;
  email: string;
  phone: string;
  neighborhood: string;
  clientType: string;
  summary: string;
  situation: string;
  returningService: string;
  bagsCount: string;
  urgency: string;
  pickupMethod: string;
  pickupTime1: string;
  pickupTime2: string;
  pickupRelease: number; // 0 or 1
  courierNotes: string;
  estimatedItems: string;
  agreementAccepted: number; // 0 or 1
  agreementTimestamp: string;
  step: number;
  createdAt: string;
}

export const WORKFLOW_STEPS = [
  { id: 1, label: "Intake & Agreement" },
  { id: 2, label: "Day-Before Confirmation" },
  { id: 3, label: "Custody Transfer" },
  { id: 4, label: "48-Hour Count Verification" },
  { id: 5, label: "Evaluation" },
  { id: 6, label: "Intake Report" },
  { id: 7, label: "Consent Window" },
  { id: 8, label: "Review Period" },
  { id: 9, label: "30-Day Payout Clock" },
];
