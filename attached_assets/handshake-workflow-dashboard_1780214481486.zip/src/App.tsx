/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { format, parseISO } from 'date-fns';
import { ChevronRight, ExternalLink, Mail, Phone, MapPin, Search } from 'lucide-react';
import { Handshake, WORKFLOW_STEPS } from './types.ts';

export default function App() {
  const [handshakes, setHandshakes] = useState<Handshake[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedHandshake, setSelectedHandshake] = useState<Handshake | null>(null);

  useEffect(() => {
    fetchHandshakes();
  }, []);

  const fetchHandshakes = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/handshakes');
      const data = await res.json();
      if (data.success) {
        setHandshakes(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const updateStep = async (id: number, step: number) => {
    try {
      // Optimistic update
      setHandshakes(prev => prev.map(h => h.id === id ? { ...h, step } : h));
      if (selectedHandshake && selectedHandshake.id === id) {
        setSelectedHandshake({ ...selectedHandshake, step });
      }

      await fetch(`/api/handshakes/${id}/step`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ step })
      });
    } catch (e) {
      console.error("Failed to update step", e);
      // Revert on failure by refetching
      fetchHandshakes();
    }
  };

  const filtered = handshakes.filter(h => 
    h.name.toLowerCase().includes(search.toLowerCase()) || 
    h.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#f5f5f0] text-[#2c2c24] font-sans selection:bg-[#d1d1c1]">
      <header className="border-b border-[#d1d1c1] px-10 py-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl tracking-tight text-[#5a5a40] italic font-serif">The Well Lived Citizen</h1>
          <p className="text-xs uppercase tracking-widest font-semibold text-[#8a8a7a] mt-1">Handshake Workflow Management</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8a8a7a]" />
            <input 
              type="text" 
              placeholder="Search clients..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 pr-4 py-2 bg-[#fafaf7] rounded-full text-xs font-bold tracking-widest border border-transparent focus:bg-white focus:border-[#d1d1c1] focus:ring-0 outline-none w-64 transition-all text-[#5a5a40]"
            />
          </div>
          <button 
            onClick={() => navigator.clipboard.writeText(window.location.origin + '/api/webhook')}
            className="text-xs px-6 py-3 bg-white text-[#5a5a40] rounded-full font-bold uppercase tracking-widest border border-[#d1d1c1] hover:bg-[#fafaf7] transition-colors flex items-center gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            Copy Webhook URL
          </button>
        </div>
      </header>

      <main className="max-w-[1600px] w-full mx-auto p-10 flex gap-8 h-[calc(100vh-101px)]">
        {/* Sidebar / List */}
        <div className="w-[400px] shrink-0 bg-white rounded-[40px] shadow-sm border border-[#e5e5d5] flex flex-col overflow-hidden">
          <div className="px-8 py-6 border-b border-[#eee] bg-[#fafaf7]">
            <h2 className="text-xl font-light text-[#3a3a2a] flex items-center justify-between font-serif">
              Open Handshakes
              <span className="bg-[#5a5a40] text-white text-[10px] px-2 py-1 rounded-full font-bold tracking-tighter uppercase">{handshakes.length} Active</span>
            </h2>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="p-8 text-center text-[#999] text-sm">Loading applications...</div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center text-[#999] text-sm">No handshakes found.</div>
            ) : (
              <ul className="divide-y divide-[#e5e0d8]">
                {filtered.map(h => (
                  <li key={h.id}>
                    <button 
                      onClick={() => setSelectedHandshake(h)}
                      className={`w-full text-left px-8 py-6 hover:bg-[#fafaf9] transition-colors ${selectedHandshake?.id === h.id ? 'bg-[#fafaf7] border-l-4 border-[#5a5a40]' : 'border-l-4 border-transparent'} border-b border-[#f0f0e8]`}
                    >
                      <div className="flex justify-between items-start mb-2">
                        <span className="font-medium text-[#2c2c24]">{h.name}</span>
                        <span className="text-[10px] text-[#8a8a7a] font-mono">
                          {format(parseISO(h.createdAt), 'MMM d')}
                        </span>
                      </div>
                      <div className="text-sm text-[#5a5a40] line-clamp-1 mb-3">
                        {h.summary || (`${h.bagsCount || 'N/A'} bags via ${h.pickupMethod}`)}
                      </div>
                      
                      {/* Mini Progress */}
                      <div className="flex flex-col gap-2">
                        <div className="flex gap-1 h-1.5 w-full">
                          {WORKFLOW_STEPS.map(s => (
                            <div 
                              key={s.id} 
                              className={`flex-1 rounded-full ${s.id <= h.step ? 'bg-[#84cc16]' : 'bg-[#e5e5d5]'}`}
                            />
                          ))}
                        </div>
                        <div className="text-[10px] uppercase font-bold tracking-tighter mt-1 flex items-center gap-1">
                          <span className={`${h.step === 9 ? 'text-[#84cc16]' : 'text-[#8a8a7a]'}`}>Step {h.step}</span>
                          <span className="text-[#d1d1c1]">•</span>
                          <span className="text-[#5a5a40]">{WORKFLOW_STEPS.find(s => s.id === h.step)?.label}</span>
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Detail View */}
        <div className="flex-1 bg-[#5a5a40] text-white rounded-[40px] shadow-lg flex flex-col overflow-hidden">
          {selectedHandshake ? (
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="p-10 border-b border-white/10">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-white/10 text-white text-[10px] font-bold uppercase tracking-widest rounded-full">
                    {selectedHandshake.clientType} Client
                  </span>
                  {selectedHandshake.agreementAccepted === 1 && (
                    <span className="px-3 py-1 bg-[#84cc16]/20 text-[#84cc16] text-[10px] font-bold uppercase tracking-widest rounded-full flex items-center gap-1.5 border border-[#84cc16]/30">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#84cc16] shadow-[0_0_8px_rgba(132,204,22,0.6)]"></div>
                      Agreement Sealed
                    </span>
                  )}
                </div>
                <h2 className="text-4xl font-light tracking-tight mb-4 font-serif text-white">{selectedHandshake.name}</h2>
                <div className="flex items-center gap-6 text-sm text-[#d1d1c1]">
                  <a href={`mailto:${selectedHandshake.email}`} className="flex items-center gap-2 hover:text-white transition-colors">
                    <Mail className="w-4 h-4" /> {selectedHandshake.email}
                  </a>
                  {selectedHandshake.phone && (
                    <span className="flex items-center gap-2">
                      <Phone className="w-4 h-4" /> {selectedHandshake.phone}
                    </span>
                  )}
                  {selectedHandshake.neighborhood && (
                    <span className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" /> {selectedHandshake.neighborhood}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-10 flex gap-12">
                {/* Left Column: Data */}
                <div className="flex-1 space-y-10">
                  {/* Intake details */}
                  <section>
                    <h3 className="text-[10px] uppercase tracking-widest text-[#d1d1c1] font-bold mb-4 border-b border-white/10 pb-2">Service Details</h3>
                    <div className="grid grid-cols-2 gap-y-6 gap-x-8 text-sm">
                      {selectedHandshake.summary && (
                        <div className="col-span-2">
                          <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Service Summary</span>
                          <span className="font-medium text-white">{selectedHandshake.summary}</span>
                        </div>
                      )}
                      {selectedHandshake.bagsCount && (
                        <div>
                          <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Estimated Bags</span>
                          <span className="font-medium text-white">{selectedHandshake.bagsCount}</span>
                        </div>
                      )}
                      {selectedHandshake.estimatedItems && (
                        <div>
                          <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Estimated Items</span>
                          <span className="font-medium text-white">{selectedHandshake.estimatedItems}</span>
                        </div>
                      )}
                      {selectedHandshake.pickupMethod && (
                        <div>
                          <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Path</span>
                          <span className="font-medium text-white capitalize">{selectedHandshake.pickupMethod.replace('-', ' ')}</span>
                        </div>
                      )}
                      {selectedHandshake.urgency && (
                        <div>
                          <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Urgency</span>
                          <span className="font-medium text-white">{selectedHandshake.urgency}</span>
                        </div>
                      )}
                    </div>
                  </section>
                  
                  {(selectedHandshake.pickupTime1 || selectedHandshake.pickupTime2 || selectedHandshake.courierNotes) && (
                    <section>
                      <h3 className="text-[10px] uppercase tracking-widest text-[#d1d1c1] font-bold mb-4 border-b border-white/10 pb-2">Logistics</h3>
                      <div className="space-y-4 text-sm">
                        {selectedHandshake.pickupTime1 && (
                          <div>
                            <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Preferred Time</span>
                            <span className="font-medium text-white">{selectedHandshake.pickupTime1}</span>
                          </div>
                        )}
                        {selectedHandshake.pickupTime2 && (
                          <div>
                            <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Backup Time</span>
                            <span className="font-medium text-white">{selectedHandshake.pickupTime2}</span>
                          </div>
                        )}
                        {selectedHandshake.pickupRelease === 1 && (
                          <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/10">
                            <div className="w-2 h-2 rounded-full bg-[#84cc16]"></div>
                            <span className="font-medium text-sm text-white">Authorized to release without Dayna present</span>
                          </div>
                        )}
                        {selectedHandshake.courierNotes && (
                          <div>
                            <span className="block text-[#a5a595] text-[10px] uppercase tracking-widest font-bold mb-1">Courier Instructions</span>
                            <p className="bg-[#2c2c24] p-4 text-[#d1d1c1] rounded-2xl text-sm whitespace-pre-wrap font-mono tracking-tight leading-relaxed">
                              {selectedHandshake.courierNotes}
                            </p>
                          </div>
                        )}
                      </div>
                    </section>
                  )}
                  
                  {selectedHandshake.situation && (
                    <section>
                      <h3 className="text-[10px] uppercase tracking-widest text-[#d1d1c1] font-bold mb-4 border-b border-white/10 pb-2">Client Context</h3>
                      <p className="text-sm leading-relaxed text-[#d1d1c1] whitespace-pre-wrap">
                        {selectedHandshake.situation}
                      </p>
                    </section>
                  )}
                  
                  <div className="text-[10px] text-[#a5a595] pt-10 font-mono break-all pb-8 leading-loose tracking-wide">
                    System ID: {selectedHandshake.id} • Intake received: {format(parseISO(selectedHandshake.createdAt), 'MMM d, yyyy HH:mm:ss')} •<br/> Agreement TS: {selectedHandshake.agreementTimestamp || 'None'}
                  </div>
                </div>

                {/* Right Column: Workflow Steps */}
                <div className="w-72 shrink-0">
                  <h3 className="text-[10px] uppercase tracking-widest text-[#d1d1c1] font-bold mb-8">Custody Pipeline</h3>
                  
                  <div className="relative">
                    <div className="absolute left-[11px] top-3 bottom-5 w-[2px] bg-white/10" />
                    
                    <ul className="space-y-6 relative">
                      {WORKFLOW_STEPS.map((step, index) => {
                        const isCurrent = step.id === selectedHandshake.step;
                        const isCompleted = step.id < selectedHandshake.step;
                        const isFuture = step.id > selectedHandshake.step;
                        
                        return (
                          <li key={step.id} className="relative flex gap-4">
                            <div className={`w-6 h-6 shrink-0 rounded-full flex items-center justify-center text-[10px] uppercase font-bold tracking-tighter z-10 ${
                              isCompleted ? 'bg-[#84cc16] text-[#2c2c24]' : 
                              isCurrent ? 'bg-white text-[#5a5a40] shadow-[0_0_12px_rgba(255,255,255,0.3)]' : 
                              'bg-[#2c2c24] border border-white/20 text-[#8a8a7a]'
                            }`}>
                              {isCompleted ? '✓' : step.id}
                            </div>
                            <div className="pt-0.5 w-full">
                              <span className={`block text-sm font-bold tracking-tight ${isFuture ? 'text-[#8a8a7a]' : 'text-white'}`}>
                                {step.label}
                              </span>
                              {isCurrent && (
                                <button 
                                  onClick={() => updateStep(selectedHandshake.id, step.id + 1)}
                                  className="mt-3 w-full py-2.5 bg-white text-[#5a5a40] rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-[#f5f5f0] transition-colors"
                                >
                                  Advance Pipeline
                                </button>
                              )}
                              {isCompleted && index === selectedHandshake.step - 2 && (
                                <button 
                                  onClick={() => updateStep(selectedHandshake.id, step.id)}
                                  className="mt-2 text-[10px] uppercase tracking-widest font-bold text-[#8a8a7a] hover:text-white transition-colors"
                                >
                                  Revert Step
                                </button>
                              )}
                            </div>
                          </li>
                        )
                      })}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-[#d1d1c1]">
              <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center mb-6">
               <ChevronRight className="w-10 h-10 opacity-50 text-white" />
              </div>
              <p className="font-serif italic text-lg">Select an intake to view custody progress.</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
