import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import Database from 'better-sqlite3';
import { createServer as createViteServer } from 'vite';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize DB (stored in workspace so it persists across container restarts during dev)
// Note: In a real Cloud Run deployment, /workspace is ephemeral or read-only without Volume mounting.
// We use a local sqlite file for prototype.
const db = new Database(path.join(__dirname, 'handshakes.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS handshakes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    phone TEXT,
    neighborhood TEXT,
    clientType TEXT,
    summary TEXT,
    situation TEXT,
    returningService TEXT,
    bagsCount TEXT,
    urgency TEXT,
    pickupMethod TEXT,
    pickupTime1 TEXT,
    pickupTime2 TEXT,
    pickupRelease INTEGER,
    courierNotes TEXT,
    estimatedItems TEXT,
    agreementAccepted INTEGER,
    agreementTimestamp TEXT,
    step INTEGER DEFAULT 1,
    createdAt TEXT DEFAULT CURRENT_TIMESTAMP
  )
`);

const insertHandshake = db.prepare(`
  INSERT INTO handshakes (
    name, email, phone, neighborhood, clientType, summary, situation, returningService,
    bagsCount, urgency, pickupMethod, pickupTime1, pickupTime2, pickupRelease,
    courierNotes, estimatedItems, agreementAccepted, agreementTimestamp, step, createdAt
  ) VALUES (
    @name, @email, @phone, @neighborhood, @clientType, @summary, @situation, @returningService,
    @bagsCount, @urgency, @pickupMethod, @pickupTime1, @pickupTime2, @pickupRelease,
    @courierNotes, @estimatedItems, @agreementAccepted, @agreementTimestamp, 1, datetime('now')
  )
`);

const updateHandshakeStep = db.prepare(`
  UPDATE handshakes SET step = @step WHERE id = @id
`);

const getAllHandshakes = db.prepare(`
  SELECT * FROM handshakes ORDER BY createdAt DESC
`);

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// API route: webhook from Replit
app.post('/api/webhook', (req, res) => {
  try {
    const data = req.body;
    
    // Webhook data from Replit form
    const info = insertHandshake.run({
      name: data.name || '',
      email: data.email || '',
      phone: data.phone || '',
      neighborhood: data.neighborhood || '',
      clientType: data.clientType || '',
      summary: data.summary || '',
      situation: data.situation || '',
      returningService: data.returningService || '',
      bagsCount: data.bagsCount || '',
      urgency: data.urgency || '',
      pickupMethod: data.pickupMethod || '',
      pickupTime1: data.pickupTime1 || '',
      pickupTime2: data.pickupTime2 || '',
      pickupRelease: data.pickupRelease === true ? 1 : 0,
      courierNotes: data.courierNotes || '',
      estimatedItems: data.estimatedItems || '',
      agreementAccepted: data.agreementAccepted === true ? 1 : 0,
      agreementTimestamp: data.agreementTimestamp || '',
    });
    
    res.status(200).json({ success: true, id: info.lastInsertRowid });
  } catch (error: any) {
    console.error("Webhook error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// API route: get all handshakes
app.get('/api/handshakes', (req, res) => {
  try {
    const handshakes = getAllHandshakes.all();
    res.status(200).json({ success: true, data: handshakes });
  } catch (error: any) {
    console.error("Fetch error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// API route: update handshake step
app.patch('/api/handshakes/:id/step', (req, res) => {
  try {
    const id = req.params.id;
    const { step } = req.body;
    
    if (typeof step !== 'number' || step < 1 || step > 9) {
      return res.status(400).json({ success: false, error: "Invalid step" });
    }
    
    const info = updateHandshakeStep.run({ step, id });
    if (info.changes === 0) {
      return res.status(404).json({ success: false, error: "Handshake not found" });
    }
    
    res.status(200).json({ success: true });
  } catch (error: any) {
    console.error("Update error:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// Setup Vite middleware internally for dev, static serving for prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Production: serve static files from dist
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
